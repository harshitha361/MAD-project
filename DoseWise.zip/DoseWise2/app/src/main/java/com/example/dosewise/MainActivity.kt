package com.example.dosewise

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.view.Gravity
import org.json.JSONArray
import android.widget.Toast
import androidx.core.content.edit

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        // Add Medicine Button

        val addMedicine = findViewById<Button>(
            R.id.btnAddMedicine
        )

        addMedicine.setOnClickListener {
            val intent = Intent(this, AddMedicineActivity::class.java)
            startActivity(intent)
        }

        // Bottom Navigation

        val home = findViewById<TextView>(
            R.id.navHome
        )

        val calendar = findViewById<TextView>(
            R.id.navCalendar
        )

        val progress = findViewById<TextView>(
            R.id.navProgress
        )

        val profile = findViewById<TextView>(
            R.id.navProfile
        )

        home.setOnClickListener {
            selectNavigation(home, "Home")
        }

        calendar.setOnClickListener {
            val intent = Intent(this, CalendarActivity::class.java)
            startActivity(intent)
        }

        progress.setOnClickListener {
            val intent = Intent(this, ProgressActivity::class.java)
            startActivity(intent)
        }

        profile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

    }
    override fun onResume() {
        super.onResume()

        if (findViewById<LinearLayout>(
                R.id.medicineListContainer
            ) != null
        ) {
            loadMedicines()
        }
    }


    @SuppressLint("UseCompatLoadingForDrawables", "SetTextI18n")
    private fun loadMedicines() {

        val container = findViewById<LinearLayout>(
            R.id.medicineListContainer
        )

        container.removeAllViews()

        val preferences = getSharedPreferences(
            "DoseWiseData",
            MODE_PRIVATE
        )

        val medicines = JSONArray(
            preferences.getString("medicines", "[]")
        )

        val statuses = JSONArray(
            preferences.getString("statuses", "[]")
        )

        for (i in 0 until medicines.length()) {

            val medicine = medicines.getJSONObject(i)

            val name = medicine.getString("name")
            val dosage = medicine.getString("dosage")
            val time = medicine.getString("time")
            val type = medicine.getString("type")
            val frequency = medicine.getString("frequency")

            val status = if (i < statuses.length()) {
                statuses.optString(i, "Pending")
            } else {
                "Pending"
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 18, 20, 18)
                background = getDrawable(
                    R.drawable.bg_medicine_card
                )

                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = 16
                }
            }

            val title = TextView(this).apply {
                text = name
                textSize = 18f
                setTextColor(getColor(R.color.text_primary))
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            val details = TextView(this).apply {
                text = "$dosage • $type"
                textSize = 14f
                setTextColor(getColor(R.color.text_secondary))
            }

            val schedule = TextView(this).apply {
                text = "$time | $frequency"
                textSize = 13f
                setTextColor(getColor(R.color.espresso))
            }

            val statusText = TextView(this).apply {
                text = "Status: $status"
                textSize = 13f
                setPadding(0, 12, 0, 8)
                setTextColor(getColor(R.color.text_primary))
            }

            val buttonLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }

            val takenButton = Button(this).apply {
                text = "Taken"
                isAllCaps = false
                setOnClickListener {
                    updateMedicineStatus(i, "Taken")
                }
            }

            val missedButton = Button(this).apply {
                text = "Missed"
                isAllCaps = false
                setOnClickListener {
                    updateMedicineStatus(i, "Missed")
                }
            }

            buttonLayout.addView(
                takenButton,
                LinearLayout.LayoutParams(0, 48, 1f)
            )

            buttonLayout.addView(
                missedButton,
                LinearLayout.LayoutParams(0, 48, 1f)
            )

            card.addView(title)
            card.addView(details)
            card.addView(schedule)
            card.addView(statusText)
            card.addView(buttonLayout)

            container.addView(card)
        }

        if (medicines.length() == 0) {
            val emptyMessage = TextView(this).apply {
                text = "No medicines added yet."
                textSize = 14f
                setTextColor(getColor(R.color.text_secondary))
                setPadding(8, 20, 8, 20)
            }

            container.addView(emptyMessage)
        }

        fun updateMedicineStatus(
            position: Int,
            newStatus: String
        ) {

            val preferences = getSharedPreferences(
                "DoseWiseData",
                MODE_PRIVATE
            )

            val medicines = JSONArray(
                preferences.getString("medicines", "[]")
            )

            val statuses = JSONArray(
                preferences.getString("statuses", "[]")
            )

            while (statuses.length() < medicines.length()) {
                statuses.put("Pending")
            }

            if (position >= 0 && position < medicines.length()) {

                val updatedStatuses = JSONArray()

                for (i in 0 until medicines.length()) {
                    updatedStatuses.put(
                        if (i == position) {
                            newStatus
                        } else {
                            statuses.optString(i, "Pending")
                        }
                    )
                }

                preferences.edit {
                    putString("statuses", updatedStatuses.toString())
                    }

                Toast.makeText(
                    this,
                    "Medicine marked as $newStatus",
                    Toast.LENGTH_SHORT
                ).show()

                loadMedicines()
            }
        }

    }

    fun updateMedicineStatus(i: Int, string: String) {}


    private fun selectNavigation(
        selected: TextView,
        screen: String
    ) {

        val navigationItems = listOf(
            R.id.navHome,
            R.id.navCalendar,
            R.id.navProgress,
            R.id.navProfile
        )

        for (id in navigationItems) {

            val item = findViewById<TextView>(id)

            item.background = null

            item.setTextColor(
                getColor(R.color.text_secondary)
            )

        }

        selected.setBackgroundResource(
            R.drawable.bg_nav_selected
        )

        selected.setTextColor(
            getColor(R.color.espresso)
        )

        if (screen != "Home") {

            Toast.makeText(
                this,
                "$screen screen coming soon!",
                Toast.LENGTH_SHORT
            ).show()

        }

    }
}
