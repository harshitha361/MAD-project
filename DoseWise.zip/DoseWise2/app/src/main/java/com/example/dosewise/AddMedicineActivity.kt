package com.example.dosewise

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import androidx.core.content.edit

class AddMedicineActivity : AppCompatActivity() {

    private lateinit var medicineName: EditText
    private lateinit var dosage: EditText
    private lateinit var medicineType: Spinner
    private lateinit var frequency: Spinner

    private lateinit var reminderTime: Button
    private lateinit var startDate: Button
    private lateinit var endDate: Button
    private lateinit var saveButton: Button

    private var selectedTime = ""
    private var selectedStartDate = ""
    private var selectedEndDate = ""

    @SuppressLint("DefaultLocale")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_medicine)

        medicineName = findViewById(R.id.etMedicineName)
        dosage = findViewById(R.id.etDosage)
        medicineType = findViewById(R.id.spMedicineType)
        frequency = findViewById(R.id.spFrequency)

        reminderTime = findViewById(R.id.btnReminderTime)
        startDate = findViewById(R.id.btnStartDate)
        endDate = findViewById(R.id.btnEndDate)
        saveButton = findViewById(R.id.btnSaveMedicine)

        // Medicine type dropdown
        val types = arrayOf(
            "Tablet", "Capsule", "Syrup",
            "Injection", "Drops", "Other"
        )

        val typeAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            types
        )
        typeAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        medicineType.adapter = typeAdapter

        // Frequency dropdown
        val frequencies = arrayOf(
            "Once a day",
            "Twice a day",
            "Three times a day",
            "Every 6 hours",
            "As needed"
        )

        val frequencyAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            frequencies
        )
        frequencyAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        frequency.adapter = frequencyAdapter

        // Time picker
        reminderTime.setOnClickListener {
            val calendar = Calendar.getInstance()

            TimePickerDialog(
                this,
                { _, hour, minute ->
                    selectedTime = String.format(
                        "%02d:%02d", hour, minute
                    )
                    reminderTime.text = selectedTime
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
            ).show()
        }

        // Start date picker
        startDate.setOnClickListener {
            showDatePicker { date ->
                selectedStartDate = date
                startDate.text = date
            }
        }

        // End date picker
        endDate.setOnClickListener {
            showDatePicker { date ->
                selectedEndDate = date
                endDate.text = date
            }
        }

        // Save medicine
        saveButton.setOnClickListener {
            saveMedicine()
        }
    }

    @SuppressLint("DefaultLocale")
    private fun showDatePicker(onDateSelected: (String) -> Unit) {
        val calendar = Calendar.getInstance()

        DatePickerDialog(
            this,
            { _, year, month, day ->
                val date = String.format(
                    "%02d/%02d/%04d",
                    day, month + 1, year
                )
                onDateSelected(date)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }


    private fun saveMedicine() {

        val name = medicineName.text.toString().trim()
        val dose = dosage.text.toString().trim()

        if (name.isEmpty()) {
            medicineName.error = "Enter medicine name"
            return
        }

        if (dose.isEmpty()) {
            dosage.error = "Enter dosage"
            return
        }

        if (selectedTime.isEmpty() ||
            selectedStartDate.isEmpty() ||
            selectedEndDate.isEmpty()
        ) {
            Toast.makeText(
                this,
                "Please select time and dates",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Validate dates properly
        val dateFormat = SimpleDateFormat(
            "dd/MM/yyyy",
            Locale.getDefault()
        ).apply {
            isLenient = false
        }

        val start = runCatching {
            dateFormat.parse(selectedStartDate)
        }.getOrNull()

        val end = runCatching {
            dateFormat.parse(selectedEndDate)
        }.getOrNull()

        if (start == null || end == null || end.before(start)) {
            Toast.makeText(
                this,
                "Please select valid dates",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Create medicine record
        val medicine = JSONObject().apply {
            put("name", name)
            put("dosage", dose)
            put("type", medicineType.selectedItem.toString())
            put("frequency", frequency.selectedItem.toString())
            put("time", selectedTime)
            put("startDate", selectedStartDate)
            put("endDate", selectedEndDate)
        }

        // Save medicine using SharedPreferences
        val preferences = getSharedPreferences(
            "DoseWiseData",
            MODE_PRIVATE
        )

        val medicines = JSONArray(
            preferences.getString("medicines", "[]")
        )

        medicines.put(medicine)

        preferences.edit {
                putString("medicines", medicines.toString())
            }

        Toast.makeText(
            this,
            "Medicine saved successfully!",
            Toast.LENGTH_SHORT
        ).show()

        finish()
    }
}
