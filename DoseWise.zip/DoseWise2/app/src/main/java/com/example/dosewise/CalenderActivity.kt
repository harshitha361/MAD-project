package com.example.dosewise


import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private val Unit.activity_calendar: Any

class CalendarActivity : AppCompatActivity() {

    private lateinit var selectedDateText: TextView
    private lateinit var medicineList: LinearLayout

    private val calendar = Calendar.getInstance()

    private val dateFormat = SimpleDateFormat(
        "dd/MM/yyyy",
        Locale.getDefault()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar)

        selectedDateText = findViewById(R.id.tvSelectedDate)
        medicineList = findViewById(R.id.calendarMedicineList)

        val chooseDate = findViewById<Button>(
            R.id.btnChooseDate
        )

        updateSelectedDate()

        chooseDate.setOnClickListener {
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    calendar.set(year, month, day)
                    updateSelectedDate()
                    loadMedicinesForDate()
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        loadMedicinesForDate()
    }

    private fun updateSelectedDate() {
        selectedDateText.text =
            dateFormat.format(calendar.time)
    }

    @SuppressLint("UseCompatLoadingForDrawables", "SetTextI18n")
    private fun loadMedicinesForDate() {

        medicineList.removeAllViews()

        val preferences = getSharedPreferences(
            "DoseWiseData",
            MODE_PRIVATE
        )

        val medicines = JSONArray(
            preferences.getString("medicines", "[]")
        )

        val selectedDate = calendar.time

        var found = false

        for (i in 0 until medicines.length()) {

            val medicine = medicines.getJSONObject(i)

            val start = runCatching {
                dateFormat.parse(medicine.getString("startDate"))
            }.getOrNull()

            val end = runCatching {
                dateFormat.parse(medicine.getString("endDate"))
            }.getOrNull()

            if (start != null && end != null &&
                !selectedDate.before(start) &&
                !selectedDate.after(end)
            ) {

                found = true

                val card = TextView(this).apply {
                    text = buildString {
                        append(medicine.getString("name"))
                        append("\n")
                        append(medicine.getString("dosage"))
                        append(" • ")
                        append(medicine.getString("time"))
                        append("\n")
                        append(medicine.getString("frequency"))
                    }

                    textSize = 15f
                    setTextColor(getColor(R.color.text_primary))
                    setPadding(20, 20, 20, 20)
                    background = getDrawable(
                        R.drawable.bg_medicine_card
                    )

                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.bottomMargin = 14
                    layoutParams = params
                }

                medicineList.addView(card)
            }
        }

        if (!found) {
            val empty = TextView(this).apply {
                text = "No medicines scheduled for this date."
                textSize = 14f
                setTextColor(getColor(R.color.text_secondary))
                setPadding(8, 20, 8, 20)
            }

            medicineList.addView(empty)
        }
    }
}
