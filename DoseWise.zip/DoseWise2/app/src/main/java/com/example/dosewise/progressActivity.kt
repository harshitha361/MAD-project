package com.example.dosewise


import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray

class ProgressActivity : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)

        val totalText = findViewById<TextView>(
            R.id.tvTotalMedicines
        )

        val takenText = findViewById<TextView>(
            R.id.tvTaken
        )

        val missedText = findViewById<TextView>(
            R.id.tvMissed
        )

        val pendingText = findViewById<TextView>(
            R.id.tvPending
        )

        val adherenceText = findViewById<TextView>(
            R.id.tvAdherence
        )

        val progressMessage = findViewById<TextView>(
            R.id.tvProgressMessage
        )

        val progressBar = findViewById<ProgressBar>(
            R.id.adherenceProgress
        )

        val preferences = getSharedPreferences(
            "DoseWiseData",
            MODE_PRIVATE
        )

        val medicines = JSONArray(
            preferences.getString("medicines", "[]")
        )

        val statuses = JSONArray(
            preferences.getString("statuses", "[]")
        )

        var taken = 0
        var missed = 0
        var pending = 0

        for (i in 0 until medicines.length()) {

            val status = statuses.optString(i, "Pending")

            when (status) {
                "Taken" -> taken++
                "Missed" -> missed++
                else -> pending++
            }
        }

        val total = medicines.length()
        val completed = taken + missed

        val adherence = if (completed > 0) {
            (taken * 100) / completed
        } else {
            0
        }

        totalText.text = "Total medicines: $total"
        takenText.text = "Medicines taken: $taken"
        missedText.text = "Medicines missed: $missed"
        pendingText.text = "Pending medicines: $pending"

        adherenceText.text = "$adherence%"
        progressBar.progress = adherence

        progressMessage.text = when {
            completed == 0 ->
                "Mark your medicines to track your progress."

            adherence >= 80 ->
                "Great work! Keep following your schedule."

            else ->
                "Keep working towards your medication goals."
        }
    }
}
