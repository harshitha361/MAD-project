package com.example.dosewise


import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit

class ProfileActivity : AppCompatActivity() {

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val nameInput = findViewById<EditText>(
            R.id.etProfileName
        )

        val emailInput = findViewById<EditText>(
            R.id.etProfileEmail
        )

        val profileName = findViewById<TextView>(
            R.id.tvProfileName
        )

        val profileEmail = findViewById<TextView>(
            R.id.tvProfileEmail
        )

        val saveButton = findViewById<Button>(
            R.id.btnSaveProfile
        )

        val notificationSwitch = findViewById<Switch>(
            R.id.switchNotifications
        )

        val preferences = getSharedPreferences(
            "DoseWiseProfile",
            MODE_PRIVATE
        )

        // Load saved profile
        val savedName = preferences.getString("name", "")
        val savedEmail = preferences.getString("email", "")

        nameInput.setText(savedName)
        emailInput.setText(savedEmail)

        profileName.text = savedName.ifEmpty {
            "DoseWise User"
        }

        savedEmail.ifEmpty {
            "Welcome to DoseWise"
        }.also { profileEmail.text = it }

        notificationSwitch.isChecked =
            preferences.getBoolean("notifications", true)

        // Save profile
        saveButton.setOnClickListener {

            val name = nameInput.text.toString().trim()
            val email = emailInput.text.toString().trim()

            if (name.isEmpty()) {
                nameInput.error = "Enter your name"
                return@setOnClickListener
            }

            if (email.isEmpty() ||
                !android.util.Patterns.EMAIL_ADDRESS
                    .matcher(email).matches()
            ) {
                emailInput.error = "Enter a valid email"
                return@setOnClickListener
            }

            preferences.edit {
            putString("name", name)
                    .putString("email", email)
                }

            profileName.text = name
            profileEmail.text = email

            Toast.makeText(
                this,
                "Profile saved successfully!",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Save notification preference
        notificationSwitch.setOnCheckedChangeListener { _, isChecked ->

            preferences.edit {
                    putBoolean("notifications", isChecked)
                }
        }
    }
}
